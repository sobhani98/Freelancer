<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       session_start();
           include 'dbh.php';           
         $project_name=$_REQUEST['pname']; 
         $p1=$_REQUEST['pname']; 
         $owner_name=$_REQUEST['ownername'];
          $worker_name=$_REQUEST['workername'];
         
           $sql3 = "DELETE FROM proj_biding WHERE proj_name='$project_name' AND username='$owner_name' AND worker_name='$worker_name';";      
              $updated = mysqli_query($conn, $sql3);
             if($updated == 1)
            {             
                                         header("Location:open_project.php?proj_name=$p1");
            }
            else
            {
                header("Location:error_page.php");
            }
        ?>
    </body>
</html>
