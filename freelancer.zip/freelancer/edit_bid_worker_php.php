<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
         if (isset($_POST["submit1"])) {
        session_start();
           include 'dbh.php';
           $days = $_POST["days"];
           $amount=$_POST["amount"];
          $workername= $_SESSION['w_n'];
           $username= $_SESSION['o_n'];
           $project_name_var1=$_SESSION['pn1'];
          
           $sql3 = "UPDATE proj_biding SET days='$days', amount=$amount WHERE proj_name='$project_name_var1' AND username='$username' AND worker_name='$workername';";      
              $updated = mysqli_query($conn, $sql3);
             if($updated == 1)
            {
              // header("Location:updated_successfully.php");
                 echo "success";
            }
            else
            {
                header("Location:error_page.php");
            }
         }
        ?>
    </body>
</html>
