<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        session_start();
        ?>
        <?php
       include 'dbh.php';
        if (isset($_POST["submit1"])) {

            $v1 = rand(1111, 9999);
            $v2 = rand(1111, 9999);
            $v3 = $v1 . $v2;
            $v3 = md5($v3);

            $fnm = $_FILES["pimage"]["name"];
            $dst = "uploaded files/" . $v3 . $fnm;
            $dst1 = "/product_image/" . $v3 . $fnm;
             move_uploaded_file($_FILES["pimage"]["tmp_name"], $dst);
                         
      $proj_cate= $_POST["cate"];
            $proj_name = $_POST["pname"];
            $proj_desc = $_POST["pdesc"];
           $budget=$_POST["budget"];
           $bdate=$_POST["bdate"];
           $username= $_SESSION['name'];
       
           $sql = "INSERT INTO projects(username,proj_cate,proj_name,proj_desc,budget,bdate,file_location) VALUES('$username','$proj_cate','$proj_name','$proj_desc',$budget,'$bdate','$dst');";
                        
              $inserted = mysqli_query($conn, $sql);
             if($inserted == 1)
            {
                header("Location:inserted_success.php");
            }
            else
            {
                header("Location:error_page.php");
            }
        }
        ?>
    </body>
</html>
