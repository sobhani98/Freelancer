<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include 'dbh.php';
        $project_name=$_REQUEST['pname'];   
        $ow_v=$_REQUEST['ownername'];   
        $wk_v=$_REQUEST['workername'];  
        $bdate_v=$_REQUEST['bdate'];  
        $sql="select * from proj_biding where proj_name='$project_name' and username='$ow_v' and worker_name='$wk_v';";
        $result1=mysqli_query($conn, $sql);                           
        while ($row4 = mysqli_fetch_array($result1)) { 
            $days=$row4['days'];
        }  
          $t1=date('Y-m-d', strtotime($bdate_v. '+'.$days.'  days'));
       
        $sql1="INSERT INTO worker_freeze(username,worker_name,proj_name,from_date,to_date) VALUES('$ow_v','$wk_v','$project_name','$bdate_v','$t1');";
        
        $inserted = mysqli_query($conn, $sql1);
             if($inserted == 1)
            {
                 
                header("Location:successfully_approved.php");
            }
            else
            {
                header("Location:already_approved.php");
            }
        ?>
    </body>
</html>
