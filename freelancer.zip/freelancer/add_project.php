class="input--style-1"<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
 <title></title>
  <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title></title>

    <!-- Icons font CSS-->
    <link href="colorlib-regform-1/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-1/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="colorlib-regform-1/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-1/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="colorlib-regform-1/css/main.css" rel="stylesheet" media="all">
    <script type="text/javascript">
   function check_category(){
    var cate=document.getElementById("cate").value;
   if(cate=="select"){
         alert("Select User Type");
         return false;
       
     }
    
 }
    </script>
    </head>
    <body>
        <?php
        include 'after_login_header.php';
        ?>       
        <br>
        <br>
        <br>
        <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Add Project</h2>
                    <form action="add_project_php.php" onsubmit="return check_category()" method="POST" enctype="multipart/form-data">                         
                              <label>Select Category</label>
                            <select name="cate"id="cate">
                                    <option value="select">Select</option>
                                     <option value="graphic_design">Graphic Design</option>
                                      <option value="web_design">Web Design</option>
                                       <option value="mobile_apps">Mobile Apps</option>                                      
                                </select>                     
                        <div class="input-group">                            
                            <input class="input--style-1" type="text" placeholder="Project Name" required name="pname">
                        </div>                      
                             <textarea class="input--style-1" rows = "5" cols = "53"placeholder="Project Description" required name="pdesc" ></textarea>
                        <div class="input-group">
                             <input class="input--style-1" type="text" placeholder="Max Budget" required name="budget">
                        </div>
                        <div class="input-group">
                            <input class="input--style-1" type="date" placeholder="Due Date to Bid" required name="bdate">
                        </div>
                          <input class="input--style-1" type="file" id="imagename"   name="pimage" 
                                 accept="" placeholder="Add the file if necessary" class="form-control">
                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit" name="submit1">Add</button>
                        </div>
                         
                    </form>
                    <form>
                         <div class="p-t-20">
                              <button class="btn btn--radius btn--green" type="submit" formaction="ownerPage.php">Back</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>    
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
