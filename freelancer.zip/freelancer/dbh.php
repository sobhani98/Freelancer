<?php
$conn=mysqli_connect("localhost","root","","mydb");
if(!$conn) 
{
	die("connection failed".mysql_connect_error());
}

?>
