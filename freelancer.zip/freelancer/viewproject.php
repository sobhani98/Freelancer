  <?php
        session_start();
        ?>

<?php
        include 'dbh.php';

$sql = "SELECT * from projects";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["username"]. " - Name: " . $row["proj_cate"] .   "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>
