<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       include 'dbh.php';
       session_start();
       $_SESSION['status']="Active";
            $uname = $_POST["username"];
            $pass = $_POST["pass"];
             echo "Uname : $uname Pass : $pass<br>";
            $sql = "SELECT * FROM users WHERE username='$uname' AND pwd='$pass';";
                        
              $result=mysqli_query($conn, $sql);
                $utype = "";
            if($row = mysqli_fetch_array($result))
            {
                $_SESSION['name']=$_POST['username'];
                $utype = $row['utype'];
                $page = $utype."Page.php";
                header("Location:$page");
            }
            else
            {
                header("Location:login.php");
            }
         
            
       
            
            
     
              
        
        ?>
    </body>
</html>
